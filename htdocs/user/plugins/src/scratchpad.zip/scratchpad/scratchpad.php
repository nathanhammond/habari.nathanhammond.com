<html>
<head><title>Habari ScratchPad</title></head>
<body>
<?php $form->out(); ?>
</body>
</html>
