<?php include 'header.php'; ?>
	<h3 class="page_title">404</h3>
	<div class="post">
		<h2 class="post_title"><span>Error!</span></h2>
		<div class="post_content">
			<p>The requested post was not found.</p>
		</div>
	</div>
<?php include 'sidebar.php'; ?>
<?php include 'footer.php'; ?>