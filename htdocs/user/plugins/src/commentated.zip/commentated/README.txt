To use this plugin, first activate it. Then, add the following to your theme where you want the comment preview to appear:

1) A container element with the ID of 'comment-preview' with a style of 'display:none'
2) A container for each field with a corresponding class (.namecontainer, .urlcontainer, .contentcontainer)
3) A placeholder for each field with a corresponding class (.nameholder, .urlholder, .contentholder)

With these elements in place, the comment preview will be enabled.