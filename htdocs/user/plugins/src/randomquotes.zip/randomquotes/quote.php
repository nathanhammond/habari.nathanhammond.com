<!-- For Random Quotes: This file can be copied and modified in a theme directory -->

<span class="randomquote">
	<p><q><?php echo htmlspecialchars( $quote_text ); ?></q></p><br /> 
	<p>&#8211; <cite><?php echo htmlspecialchars( $quote_author ); ?></cite></p> 
</span>
