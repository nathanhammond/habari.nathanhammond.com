<?php
class RateItLogs extends ArrayObject
{
}
?>