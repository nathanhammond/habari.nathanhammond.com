</div>
<?php
// Uncomment this to view your DB profiling info
// include 'db_profiling.php';
?>
</body>
</html>