<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>
	<div id="content" class="with_title">
		<h3 class="page_title">404</h3>
		<div class="post">
			<div class="post_head">
				<h2>Error!</h2>
			</div>
			<div class="post_content">
				<p>The requested post was not found.</p>
			</div>
		</div>
	</div>
<?php include 'footer.php'; ?>