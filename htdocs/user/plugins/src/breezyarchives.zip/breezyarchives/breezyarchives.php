<ul id="breezyarchives">
	<li class="type"><h3><?php echo $chronology_title; ?></h3><?php $theme->chronology_archives(); ?></li>
	<li class="type"><h3><?php echo $taxonomy_title; ?></h3><?php $theme->taxonomy_archives(); ?></li>
</ul>