<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>
	<h3 class="page_title">404</h3>
	<div class="post">
		<h2 class="post_title">Error!</h2>
		<div class="post_content">
			<p>The requested post was not found.</p>
		</div>
	</div>
<?php include 'footer.php'; ?>