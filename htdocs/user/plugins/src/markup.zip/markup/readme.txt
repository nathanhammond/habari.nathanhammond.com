Plugin: markUp
URL: http://habariproject.org
Version: 0.21
Author: Habari Project

Purpose 

markUp is based on the markItUp! jQuery plugin by Jay Salvat (http://markitup.jaysalvat.com/). It provides a simple html text editor for those of us who want the productivity improvements of not having to type in all our own html tags, but don't want to use a wysiwyg editor. 

Out of the box markUp provides easy insertion of all header tags, paragraphs, unordered and ordered lists, images, and links.

Requirements 

Just activate it.

Installation

1. Copy the plugin directory into your user/plugins directory or the site's plugins directory.
2. Go to the plugins page of your Habari admin panel.
3. Click on the Activate button for markItUp.

Uninstallation

1. Got to the plugins page of your Habari admin panel.
2. Click on the Deactivate button.
3. Delete the markItUp directory from your user/plugins directory.

Cleanup

markItUp makes no changes to your database, so no cleanup is required.

Changelog

Version 0.21
Fix: Move content label into the edit area of the content textarea.

Version 0.2
Fix: Changes necessitated by admin api changes

Version 0.1
Initial release