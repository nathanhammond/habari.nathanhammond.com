$(document).ready(function() {
	$(".post, blockquote, .post-tags, #prev-posts, #archives, #tags, .post-date, .post-comments-link a, .nav-prev, .nav-next, #search-btn, .feedlink a, img[@src$=pwrd_habari.png]").pngfix({sizingMethod: "crop"});	
});